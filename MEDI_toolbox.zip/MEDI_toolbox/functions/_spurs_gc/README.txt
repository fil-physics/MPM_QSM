

1. The main function of joint water fat separation and field map estimation is
spurs_gc.m

2. The main function of phase unwrapping using graph cut is 

unwrapping_gc.m


This version added the option of subsample for speed up.
by Jianwu Dong
2014.9.3 