#if !defined(__LIBPROB_H)
#define __LIBPROB_H

#if defined(__cplusplus)
namespace MISCMATHS {
#endif

#include "cprob.h"

#if defined(__cplusplus)
}
#endif

#endif
